<?php
/**
 * KimPu Theme — Professional portfolio footer.
 * @package KimPuTheme
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$footer_bio      = get_theme_mod( 'kimpu_footer_bio', 'I create thoughtful, modern websites and digital experiences with a focus on performance, usability, and clean design.' );
$footer_email    = sanitize_email( get_theme_mod( 'kimpu_footer_email', '' ) );
$footer_location = get_theme_mod( 'kimpu_footer_location', '' );

$social_links = array(
    'GitHub'    => get_theme_mod( 'kimpu_social_github', '' ),
    'LinkedIn'  => get_theme_mod( 'kimpu_social_linkedin', '' ),
    'Facebook'  => get_theme_mod( 'kimpu_social_facebook', '' ),
    'Instagram' => get_theme_mod( 'kimpu_social_instagram', '' ),
);
$social_links = array_filter( $social_links, 'strlen' );

$contact_page = get_page_by_path( 'contact' );
$contact_url  = ( $contact_page instanceof WP_Post && 'publish' === $contact_page->post_status )
    ? get_permalink( $contact_page )
    : '';
if ( ! $contact_url && is_email( $footer_email ) ) {
    $contact_url = 'mailto:' . $footer_email;
}
?>
<footer class="kp-footer" id="site-footer">
    <div class="kp-footer-container">
        <section class="kp-footer-cta" aria-labelledby="kp-footer-cta-title">
            <div class="kp-footer-cta-copy">
                <span class="kp-footer-eyebrow">LET'S COLLABORATE</span>
                <h2 id="kp-footer-cta-title">Have an idea? Let's make it real.</h2>
                <p>Have a project, question, or idea in mind? I'd love to hear about it.</p>
            </div>
            <?php if ( $contact_url ) : ?>
                <a class="kp-footer-button" href="<?php echo esc_url( $contact_url ); ?>">
                    Let's talk <span aria-hidden="true">↗</span>
                </a>
            <?php endif; ?>
        </section>

        <div class="kp-footer-grid">
            <div class="kp-footer-brand-col">
                <?php if ( has_custom_logo() ) : ?>
                    <div class="kp-footer-logo-wrap"><?php the_custom_logo(); ?></div>
                <?php else : ?>
                    <a class="kp-footer-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> homepage">
                        <span class="kp-footer-brand-mark" aria-hidden="true">K</span>
                        <span>KimPu<span class="kp-footer-brand-dot">.</span></span>
                    </a>
                <?php endif; ?>
                <p class="kp-footer-description"><?php echo esc_html( $footer_bio ); ?></p>
            </div>

            <nav class="kp-footer-links" aria-label="Footer navigation">
                <h3>Explore</h3>
                <?php if ( has_nav_menu( 'footer' ) ) : ?>
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'footer',
                        'container'      => false,
                        'menu_class'     => 'kp-footer-menu',
                        'depth'          => 1,
                        'fallback_cb'    => false,
                    ) );
                    ?>
                <?php else : ?>
                    <ul class="kp-footer-menu">
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                        <?php
                        foreach ( array( 'about' => 'About', 'projects' => 'Projects', 'blog' => 'Blog', 'contact' => 'Contact' ) as $slug => $label ) {
                            $page = get_page_by_path( $slug );
                            if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
                                echo '<li><a href="' . esc_url( get_permalink( $page ) ) . '">' . esc_html( $label ) . '</a></li>';
                            }
                        }
                        ?>
                    </ul>
                <?php endif; ?>
            </nav>

            <div class="kp-footer-connect">
                <h3>Get in touch</h3>
                <p>Let's connect and create something meaningful.</p>
                <?php if ( is_email( $footer_email ) ) : ?>
                    <a class="kp-footer-email" href="mailto:<?php echo esc_attr( $footer_email ); ?>">
                        <?php echo esc_html( $footer_email ); ?> <span aria-hidden="true">↗</span>
                    </a>
                <?php endif; ?>
                <?php if ( $footer_location ) : ?>
                    <p class="kp-footer-location"><?php echo esc_html( $footer_location ); ?></p>
                <?php endif; ?>
                <?php if ( $social_links ) : ?>
                    <div class="kp-footer-socials" aria-label="Social profiles">
                        <?php foreach ( $social_links as $name => $url ) : ?>
                            <a href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( $name ); ?>">
                                <?php echo esc_html( $name ); ?> <span aria-hidden="true">↗</span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="kp-footer-bottom">
            <p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. All rights reserved.</p>
            <div class="kp-footer-bottom-actions">
                <?php if ( get_privacy_policy_url() ) : ?>
                    <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>">Privacy Policy</a>
                <?php endif; ?>
                <a class="kp-footer-backtop" href="#" aria-label="Back to top">Back to top <span aria-hidden="true">↑</span></a>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
