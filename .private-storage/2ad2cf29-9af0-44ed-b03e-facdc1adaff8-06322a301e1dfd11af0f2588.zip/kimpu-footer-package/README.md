# KimPu Professional Footer (for existing kimpu-theme)

Copy these files into your existing WordPress theme folder:

- `footer.php` -> `wp-content/themes/kimpu-theme/footer.php` (replaces existing footer.php)
- `assets/css/footer.css` -> `wp-content/themes/kimpu-theme/assets/css/footer.css`
- `inc/footer-setup.php` -> `wp-content/themes/kimpu-theme/inc/footer-setup.php`

Then ADD this one line to the BOTTOM of your existing `functions.php` (do not replace the file):

```php
require_once get_template_directory() . '/inc/footer-setup.php';
```

WordPress Admin:
1. Appearance > Customize > Footer Settings: edit description, email, location, social URLs.
2. Appearance > Menus: create a Footer Menu and assign to Footer Navigation.
3. Customize > Site Identity: upload a logo. Footer uses the same logo.
4. For the `Let's talk` button: create a published page with slug `contact`, or configure a public contact email in Footer Settings.
5. If no footer menu is assigned, the footer displays Home and existing published pages with slugs `about`, `projects`, `blog`, `contact`.
6. Clear caches and refresh the site.

This addon assumes the Phase 2 Theme's `kimpu-style` stylesheet is registered by the existing `functions.php`.
