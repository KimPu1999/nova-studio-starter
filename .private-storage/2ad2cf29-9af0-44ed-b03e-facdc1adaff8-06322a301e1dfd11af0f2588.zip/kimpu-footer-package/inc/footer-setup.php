<?php
/** Footer setup: include once from functions.php. */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function kimpu_footer_register_menu() {
    register_nav_menu( 'footer', __( 'Footer Navigation', 'kimpu-theme' ) );
}
add_action( 'after_setup_theme', 'kimpu_footer_register_menu' );

function kimpu_footer_enqueue_styles() {
    $relative = '/assets/css/footer.css';
    $absolute = get_template_directory() . $relative;
    wp_enqueue_style(
        'kimpu-footer',
        get_template_directory_uri() . $relative,
        array( 'kimpu-style' ),
        file_exists( $absolute ) ? (string) filemtime( $absolute ) : '1.0.0'
    );
}
add_action( 'wp_enqueue_scripts', 'kimpu_footer_enqueue_styles', 20 );

function kimpu_footer_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'kimpu_footer', array(
        'title'       => __( 'Footer Settings', 'kimpu-theme' ),
        'description' => __( 'Edit footer description, contact details, and social links.', 'kimpu-theme' ),
        'priority'    => 160,
    ) );

    $fields = array(
        'kimpu_footer_bio' => array(
            'label' => 'Short description', 'type' => 'textarea',
            'default' => 'I create thoughtful, modern websites and digital experiences with a focus on performance, usability, and clean design.',
            'sanitize' => 'sanitize_textarea_field',
        ),
        'kimpu_footer_email' => array(
            'label' => 'Public contact email', 'type' => 'email', 'default' => '', 'sanitize' => 'sanitize_email',
        ),
        'kimpu_footer_location' => array(
            'label' => 'Location (optional)', 'type' => 'text', 'default' => '', 'sanitize' => 'sanitize_text_field',
        ),
        'kimpu_social_github' => array(
            'label' => 'GitHub URL', 'type' => 'url', 'default' => '', 'sanitize' => 'esc_url_raw',
        ),
        'kimpu_social_linkedin' => array(
            'label' => 'LinkedIn URL', 'type' => 'url', 'default' => '', 'sanitize' => 'esc_url_raw',
        ),
        'kimpu_social_facebook' => array(
            'label' => 'Facebook URL', 'type' => 'url', 'default' => '', 'sanitize' => 'esc_url_raw',
        ),
        'kimpu_social_instagram' => array(
            'label' => 'Instagram URL', 'type' => 'url', 'default' => '', 'sanitize' => 'esc_url_raw',
        ),
    );

    foreach ( $fields as $id => $field ) {
        $wp_customize->add_setting( $id, array(
            'default'           => $field['default'],
            'sanitize_callback' => $field['sanitize'],
            'transport'         => 'refresh',
        ) );
        $wp_customize->add_control( $id, array(
            'label'   => __( $field['label'], 'kimpu-theme' ),
            'section' => 'kimpu_footer',
            'type'    => $field['type'],
        ) );
    }
}
add_action( 'customize_register', 'kimpu_footer_customize_register' );
