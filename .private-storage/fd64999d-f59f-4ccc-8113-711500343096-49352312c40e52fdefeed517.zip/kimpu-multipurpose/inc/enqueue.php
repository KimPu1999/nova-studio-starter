<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function kimpu_assets() {
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'kimpu-style', get_stylesheet_uri(), array(), $version );
    wp_enqueue_style( 'kimpu-main', get_template_directory_uri() . '/assets/css/main.css', array( 'kimpu-style' ), $version );
    wp_enqueue_script( 'kimpu-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), $version, true );
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
    $primary = get_theme_mod( 'kimpu_primary_color', '#137c66' );
    $primary = sanitize_hex_color( $primary );
    if ( $primary ) { wp_add_inline_style( 'kimpu-main', ':root{--color-primary:' . $primary . ';}' ); }
}
add_action( 'wp_enqueue_scripts', 'kimpu_assets' );
