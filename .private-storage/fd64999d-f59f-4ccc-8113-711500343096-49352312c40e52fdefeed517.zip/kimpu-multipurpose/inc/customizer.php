<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function kimpu_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'kimpu_design', array(
        'title' => __( 'Theme Design', 'kimpu-multipurpose' ),
        'priority' => 35,
    ) );
    $wp_customize->add_setting( 'kimpu_primary_color', array(
        'default' => '#137c66',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'kimpu_primary_color', array(
        'label' => __( 'Primary Color', 'kimpu-multipurpose' ),
        'section' => 'kimpu_design',
    ) ) );
    $wp_customize->add_setting( 'kimpu_hero_title', array(
        'default' => __( 'Build a better digital presence.', 'kimpu-multipurpose' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'kimpu_hero_title', array(
        'label' => __( 'Homepage Hero Title', 'kimpu-multipurpose' ),
        'section' => 'kimpu_design',
        'type' => 'text',
    ) );
    $wp_customize->add_setting( 'kimpu_hero_text', array(
        'default' => __( 'A clean, flexible WordPress foundation designed to grow with your ideas.', 'kimpu-multipurpose' ),
        'sanitize_callback' => 'sanitize_textarea_field',
    ) );
    $wp_customize->add_control( 'kimpu_hero_text', array(
        'label' => __( 'Homepage Hero Description', 'kimpu-multipurpose' ),
        'section' => 'kimpu_design',
        'type' => 'textarea',
    ) );
}
add_action( 'customize_register', 'kimpu_customize_register' );
