<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<footer class="site-footer">
    <div class="container footer-inner">
        <div>
            <a class="footer-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
            <p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
        </div>
        <nav aria-label="<?php esc_attr_e( 'Footer menu', 'kimpu-multipurpose' ); ?>">
            <?php if ( has_nav_menu( 'footer' ) ) { wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1 ) ); } ?>
        </nav>
    </div>
    <div class="container footer-bottom">&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'All rights reserved.', 'kimpu-multipurpose' ); ?></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
