<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'kimpu-multipurpose' ); ?></a>
<header class="site-header" id="site-header">
    <div class="container header-inner">
        <div class="site-branding">
            <?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
                <a class="brand-name" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
            <?php endif; ?>
        </div>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-menu" aria-label="<?php esc_attr_e( 'Toggle navigation', 'kimpu-multipurpose' ); ?>">
            <span aria-hidden="true">☰</span>
        </button>
        <nav class="primary-nav" id="primary-menu" aria-label="<?php esc_attr_e( 'Primary menu', 'kimpu-multipurpose' ); ?>">
            <?php wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_id' => 'site-navigation-list',
                'container' => false,
                'fallback_cb' => 'wp_page_menu',
                'depth' => 2,
            ) ); ?>
        </nav>
    </div>
</header>
