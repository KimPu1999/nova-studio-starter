(() => {
  const button = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('.primary-nav');
  if (!button || !navigation) return;
  const close = () => { button.setAttribute('aria-expanded', 'false'); navigation.classList.remove('is-open'); };
  button.addEventListener('click', () => {
    const expanded = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', String(!expanded));
    navigation.classList.toggle('is-open', !expanded);
  });
  navigation.addEventListener('click', (event) => { if (event.target.closest('a') && matchMedia('(max-width: 800px)').matches) close(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') close(); });
  document.addEventListener('click', (event) => { if (!navigation.contains(event.target) && !button.contains(event.target)) close(); });
  window.addEventListener('resize', () => { if (window.innerWidth > 800) close(); });
})();
